window.onload=function change() {
    let btn=document.getElementById('change');
    let h2=document.getElementById('title');
    // let line=document.getElementById('line');
    let title=document.getElementById('title')
    // let after_style=window.getComputedStyle(title,":after")
    // let title_change=document.getElementById('title_change')
    let count=0;
    btn.onclick=function () {
        if(count%2===0){
            // line.style.width = "100%";
            h2.style.animation = "changeColor1 1s";
            h2.style.color = "darkseagreen";
            title.id = "title_change";
            count++;
        }else {
            // line.style.width = "0%";
            h2.style.animation = "changeColor2 1s";
            h2.style.color = "#000";
            title.id = "title";
            count++;
        }
       }
};